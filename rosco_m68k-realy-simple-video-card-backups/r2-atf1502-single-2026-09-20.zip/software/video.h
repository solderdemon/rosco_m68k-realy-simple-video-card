/*
 * rosco_m68k Really Simple Video r2 driver: 640 x 480, 1 bit per pixel, one page.
 *
 * Byte access only (/LDS), odd addresses:
 *   $A00001 + 2n   VRAM byte n = y << 7 | x >> 3   (128 bytes per row, 80 of them visible;
 *                  bit 7 of a byte is its leftmost pixel)
 *   $B00001        write: b0 video on (1)          system reset: 0 = black screen
 *                  read:  b0 VBLANK (1 = in vertical blanking); b1-b7 are not driven, mask them
 * The register repeats over $B00001-$BFFFFF; even addresses in $A00000-$BFFFFF end in a bus error.
 * The control register cannot be read back, so the driver keeps a copy.
 *
 * r2 fits the whole card into one ATF1502AS, which left no pins for a second video page: any CPU
 * access while the picture is on steals one byte fetch and shows up as eight wrong pixels on the
 * current scanline. Draw inside vertical blanking -- video_wait_vblank() gives you about 1.4 ms
 * of it per frame -- or accept the flicker.
 */
#ifndef ROSCO_VIDEO_H
#define ROSCO_VIDEO_H

#include <stdbool.h>
#include <stdint.h>

#define VIDEO_VRAM_BASE   0xA00001UL
#define VIDEO_REG         0xB00001UL

#define VIDEO_WIDTH       640
#define VIDEO_HEIGHT      480
#define VIDEO_STRIDE      128          /* VRAM bytes per row; 80 of them are on screen */
#define VIDEO_COLS        (VIDEO_WIDTH / 8)     /* 80 characters */
#define VIDEO_ROWS        (VIDEO_HEIGHT / 8)    /* 60 lines */

#define VIDEO_CTRL_ON     0x01
#define VIDEO_STAT_VBLANK 0x01

/* CPU address of the byte holding pixel (x, y); the card sees only odd addresses. */
#define VIDEO_ADDR(x, y) (VIDEO_VRAM_BASE + ((uint32_t)(y) << 8) + (((uint32_t)(x) >> 3) << 1))

/* Video off. Does not clear VRAM -- call video_clear. */
void video_init(void);

/* Control register. `on` false blanks the screen without disturbing VRAM. */
void video_on(bool on);
bool video_is_on(void);

/* Raw status byte, already masked to VIDEO_STAT_VBLANK. */
uint8_t video_status(void);

/* Return at the start of the next vertical blanking interval. */
void video_wait_vblank(void);

/* c: 0 = black, anything else = lit. Coordinates outside the screen are ignored. */
void video_pixel(unsigned x, unsigned y, unsigned c);
unsigned video_get(unsigned x, unsigned y);
void video_clear(unsigned c);
void video_hline(unsigned x, unsigned y, unsigned w, unsigned c);
void video_vline(unsigned x, unsigned y, unsigned h, unsigned c);
void video_fill(unsigned x, unsigned y, unsigned w, unsigned h, unsigned c);
void video_rect(unsigned x, unsigned y, unsigned w, unsigned h, unsigned c);
void video_line(int x0, int y0, int x1, int y1, unsigned c);

/* 8 x 8 text on an 80 x 60 grid. `inv` swaps ink and paper. */
extern const uint8_t video_font8x8[95][8];
void video_char(unsigned col, unsigned row, char ch, bool inv);
void video_text(unsigned col, unsigned row, const char *s);

/* Walk every VRAM cell with two patterns; 0 = pass, otherwise the failing byte number + 1.
 * Destroys the framebuffer. */
uint32_t video_selftest(void);

#endif
