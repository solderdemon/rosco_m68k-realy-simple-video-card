/*
 * rosco_m68k Really Simple Video demo: self test, a text page, then a moving box redrawn inside
 * vertical blanking so the CPU never steals a byte fetch while the picture is being scanned.
 *
 * Build with the rosco_m68k toolchain (see docs/BUILD.md) and load the .bin over the serial
 * bootloader. Progress goes to the serial console as well as to the screen.
 */
#include <stdio.h>
#include <stdbool.h>
#include "video.h"

int main(void)
{
    uint32_t bad;
    int bx = 100, by = 100, dx = 3, dy = 2;
    unsigned frame;

    printf("Really Simple Video: testing 60K of VRAM...\n");
    video_init();
    bad = video_selftest();
    if (bad) {
        printf("VRAM FAILED at byte %lu (y %lu, byte %lu)\n", (unsigned long)(bad - 1),
               (unsigned long)((bad - 1) >> 7), (unsigned long)((bad - 1) & 0x7F));
        return 1;
    }
    printf("VRAM ok. 640x480 should now be on the VGA output.\n");

    video_clear(0);
    video_rect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT, 1);
    video_text(2, 2, "rosco_m68k Really Simple Video r2");
    video_text(2, 4, "640 x 480 @ 60 Hz, 1 bit per pixel, 80 x 60 characters");
    video_text(2, 5, "VRAM  $A00001 + 2n,  n = y << 7 | x >> 3");
    video_text(2, 6, "control / status at $B00001, one ATF1502AS-10JU44");
    for (frame = 0; frame < 16; frame++) {
        char line[65];
        unsigned i;

        for (i = 0; i < 64; i++)
            line[i] = (char)(32 + ((frame * 64 + i) % 95));
        line[64] = 0;
        video_text(2, 9 + frame, line);
    }
    video_line(0, 0, VIDEO_WIDTH - 1, VIDEO_HEIGHT - 1, 1);
    video_line(VIDEO_WIDTH - 1, 0, 0, VIDEO_HEIGHT - 1, 1);
    video_on(true);

    for (frame = 0; frame < 120; frame++)
        video_wait_vblank();

    /* The moving box. Erase and redraw inside blanking: with a single page that is what keeps
     * the picture free of the eight-pixel flicker a CPU access causes. */
    video_clear(0);
    video_rect(0, 0, VIDEO_WIDTH, VIDEO_HEIGHT, 1);
    video_text(2, 1, "drawing inside VBLANK -- no snow");
    for (;;) {
        video_wait_vblank();
        video_fill((unsigned)bx, (unsigned)by, 96, 64, 0);
        bx += dx;
        by += dy;
        if (bx < 4 || bx + 96 > VIDEO_WIDTH - 4)
            dx = -dx;
        if (by < 4 || by + 64 > VIDEO_HEIGHT - 4)
            dy = -dy;
        video_fill((unsigned)bx, (unsigned)by, 96, 64, 1);
    }
}
