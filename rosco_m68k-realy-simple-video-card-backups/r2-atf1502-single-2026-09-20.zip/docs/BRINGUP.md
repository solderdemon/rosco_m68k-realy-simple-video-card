# Assembling and bringing up the card

No board has been manufactured yet — this is the procedure to follow with the first one, written
so that a fault stops you at the step that can still explain it.

Before anything else, read the fitter warning in the [README](../README.md#verification): this
revision uses 32 of 32 pins and 31 of 32 macrocells of the ATF1502AS and has never been through
WinCUPL. **Compile the CPLD firmware before you order the PCB.** If the fitter will not place the
design on the pins in `cpld/rsv1502.pld`, the board is wrong and there is no point having it made.

## 1. Compile and program the CPLD

You need Microchip's WinCUPL (free) with the ATF150x fitter, and a JTAG programmer — a USB Blaster
clone driven by ATMISP or OpenOCD is enough.

1. Open `cpld/rsv1502.pld` in WinCUPL. The device (`f1502ispplcc44`) and the pin assignment are
   already in the file, along with `PREASSIGN = KEEP`, which tells the fitter to honour them.
2. `Run → Device Dependent Compile`. WinCUPL calls the `fit1502` fitter.
3. Check `rsv1502.fit`: every pin number must match the `.pld`, JTAG must be ON, and the macrocell
   count must be within 32.
4. The result is `rsv1502.jed`. Program it through J3.

If the fitter refuses the assignment, see [DESIGN §10](DESIGN.md#10-if-the-fitter-says-no) — the
first thing to try is letting it choose the pins and then feeding its pinout back into the `.pld`
and regenerating the board. Never fix a pin conflict by editing the schematic: the schematic is
generated from that file.

The CPLD can be programmed in the socket on the finished board — J3 is wired to +5 V and ground,
so the card must be in a powered backplane while you do it.

## 2. Solder

Order: sockets, then resistors and capacitors, then J1, J2 and J3, then the oscillator.

- **Every IC goes in a socket.** 1 × PLCC-44 through-hole socket, 3 × DIP-16, 1 × DIP-20,
  1 × DIP-32 (600 mil), 1 × DIP-8 for the oscillator. Note the PLCC socket's pin 1 corner — the
  chamfered corner on the silkscreen.
- **U8 must be a 74AC166 or 74ACT166**, not a 74HC166: it runs at 25.175 MHz and drives about
  25 mA into the three video resistors.
- **U2–U5 are 74HCT157.** HCT is deliberate — they are fed by 5 V CMOS and have 230 ns to settle.
- **X1 is a canned oscillator**, not a crystal. 25.175 MHz.
- R1, R2 and R3 are 470 Ω (video), R4 and R5 are 47 Ω (sync). They stand in one row above J2, left
  to right R4 R5 R1 R2 R3 = HSYNC, VSYNC, red, green, blue. Fitting only R2 gives a green screen,
  only R1 + R2 an amber one.
- C11 is polarised: the long leg goes to +5 V.

Before putting any IC in its socket, power the card from the bus and check +5 V and 0 V on every
socket's supply pins — including all four VCC/GND pairs of the PLCC socket (3, 15, 23, 35 and
10, 22, 30, 42).

## 3. First power-up: the raster alone

Fit **only X1 and U1**. Leave the muxes, the SRAM, the transceiver and the serialiser out.

Plug a monitor into J2. The screen will be black, but it should **lock**: the OSD should report
640 × 480 at 60 Hz rather than "no signal" or "out of range".

| Symptom | Look at |
|---|---|
| No signal at all | X1 pin 5: 25.175 MHz. Then U1 pin 43 (GCLK1) — the same signal |
| Out of range, or the picture rolls | U1 pin 40 (/HSYNC): 31.47 kHz, 3.8 µs low. U1 pin 41 (/VSYNC): 59.94 Hz |
| Locks at the wrong rate | the wrong `.jed`, or the fitter moved a pin and the board was not regenerated |

With U1 alone you can also watch the byte counter on pins 4–12 (B0–B6) and the line counter on
14–25 (L0–L8) — B should be a clean 3.15 MHz on B0, L a clean 15.7 kHz on L0.

## 4. The rest of the card

Power down, fit U2–U8, and power up again. The screen should still be black — `/RESET` clears
`VIDEOON`, so the card comes up blanked on purpose.

Now load the demo (`software/`, see [BUILD.md](BUILD.md)) over the serial bootloader. It runs the
VRAM self test first and prints the result to the serial console:

```
Really Simple Video: testing 60K of VRAM...
VRAM ok. 640x480 should now be on the VGA output.
```

`video_selftest()` writes the whole page before reading any of it back, so a stuck or shorted
address line shows up as one row overwriting another rather than as a picture that is subtly
wrong.

| Symptom | Likely cause |
|---|---|
| Bus error on the first VRAM write | `/DTACK` — U1 pin 39 to J1 pin 57 |
| Self test fails on a regular pattern of bytes | an MA line: check U2–U5 outputs against U6's pins |
| Self test passes, screen stays black | `VIDEOON` never got set (U1 pin 31 = D0 to J1 pin 61), or `/LOAD` (U1 pin 29 → U8 pin 15) |
| A picture, but every eighth pixel column wrong | U8 data pins: A = MD0 … H = MD7 |
| The picture is mirrored inside each byte | same — A and H swapped |
| Picture shifted sideways by one byte | the HBLANK decode; it should stop the load at byte 79 |
| Garbage on the data bus during writes | the BUFD delay — see [DESIGN §6](DESIGN.md#sram-oe-and-bufd) |

## 5. Things worth a scope

- **MD during a VRAM write.** `WE#` (U6 pin 29) falls with `/LDS`; `/BUF_OE` (U1 pin 28) must fall
  one 25 MHz clock later, about 40 ns. If they move together, the SRAM and the 74HCT245 briefly
  fight over MD. This is the one place r2 trades a pin for a timing assumption.
- **The video byte fetch.** The byte-clock edge to valid data on U6's DQ pins should be under
  about 90 ns of the 318 ns available.
- **Snow.** Writing to VRAM while the picture is on will flicker eight pixels on the current line.
  That is expected with one page; draw inside `video_wait_vblank()`.

## 6. Still to be verified on real hardware

- **that the design fits an ATF1502AS at all** — see step 1;
- real propagation delays, inside the CPLD and on the board;
- the BUFD timing above;
- the 0.62 V video level on a real monitor, and monitor tolerance of the timing;
- a build with the rosco_m68k toolchain;
- the board itself — no PCB has been ordered.
