#!/usr/bin/env bash
# Assemble the four GALs with GALasm 2.1 (see docs/BUILD.md) and, with "burn", program them
# with minipro (TL866II+/T48). Each chip is an ATF22V10C; label them U1-U4 as you go.
set -e
cd "$(dirname "$0")"
for f in u1_bus u2_timing u3_column u4_line; do
    galasm "$f.pld"
done
if [ "$1" = burn ]; then
    for f in u1_bus u2_timing u3_column u4_line; do
        read -rp "Insert the ATF22V10C for $f and press Enter "
        minipro -p "ATF22V10C(UES)" -w "$f.jed"
    done
fi
