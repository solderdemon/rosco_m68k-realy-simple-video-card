# Assembling and bringing up the card

No board has been manufactured yet — this is the procedure to follow with the first one, written
so that a fault stops you at the step that can still explain it.

## 1. Program the four GALs

All four are ATF22V10C. A `-15` part is fast enough everywhere on this card; `-10` or `-7` are
fine too.

```sh
GALASM=... ./pld/build.sh        # assemble
./pld/build.sh burn              # and program, one at a time, with minipro
```

or by hand:

```sh
minipro -p "ATF22V10C(UES)" -w pld/u1_bus.jed
```

Label them as you go — `u1_bus` → U1, `u2_timing` → U2, `u3_column` → U3, `u4_line` → U4. The
four chips are physically identical and swapping two of them produces a board that looks alive and
shows nothing.

## 2. Solder

Order: sockets, then resistors and capacitors, then J1 and J2, then the oscillator.

- **Every IC goes in a socket.** 4 × DIP-24 (300 mil), 4 × DIP-16, 1 × DIP-20, 1 × DIP-32
  (600 mil), 1 × DIP-8 for the oscillator.
- **U11 must be a 74AC166 or 74ACT166**, not a 74HC166: it runs at 25.175 MHz and drives about
  25 mA into the three video resistors.
- **U5–U8 are 74HCT157.** HCT is deliberate — these are fed by 5 V CMOS and have 230 ns to settle.
- **X1 is a canned oscillator**, not a crystal. 25.175 MHz.
- R1, R2 and R3 are 470 Ω (video), R4 and R5 are 47 Ω (sync). They stand in one row above J2,
  left to right R4 R5 R1 R2 R3 = HSYNC, VSYNC, red, green, blue. Fitting only R2 gives a green
  screen, only R1 + R2 an amber one.
- C13 is polarised: the long leg goes to +5 V.

Before putting any IC in its socket, power the card from the bus and check +5 V and 0 V on every
socket's supply pins.

## 3. First power-up

Fit **only X1, U2, U3 and U4** — the timing chain. Leave the bus GAL, the SRAM, the muxes and the
serialiser out. `VIDEO_ON` comes from U1, so with U1 out of its socket U2 pin 11 is floating and a
CMOS input must not be left like that: tack a wire from U2 pin 11 to +5 V for this step, and remove
it before fitting U1. Sync comes out either way, but the wire keeps U2's blanking logic honest.

Plug a monitor into J2. It will show a black screen, but it should **lock**: the OSD should report
640 × 480 at 60 Hz rather than "no signal" or "out of range".

If it does not:

| Symptom | Look at |
|---|---|
| No signal at all | X1 pin 5: 25.175 MHz. Then U2 pin 17 (BCLK): 3.147 MHz |
| Out of range, or the picture rolls | U3 pin 16 (/HSYNC): 31.47 kHz, 3.8 µs low. U2 pin 20 (/VSYNC): 59.94 Hz |
| Locks at the wrong rate | U3 or U4 programmed with the wrong file, or swapped |

Useful test points, all unconnected GAL output pins: U2 pin 14/15/16 = PH0/PH1/PH2, U2 pin 19 =
BLANK, U3 pin 14 = LAST, U1 pin 19 = PAGE.

## 4. The rest of the card

Power down, fit U1, U5–U9, U10 and U11, and power up again. The screen should still be black —
`/RESET` clears `VIDEO_ON`, so the card comes up blanked on purpose.

Now load the demo (`software/`, see [BUILD.md](BUILD.md)) over the serial bootloader. It runs the
VRAM self test first and prints the result to the serial console:

```
Really Simple Video: testing 128K of VRAM...
VRAM ok. 640x480 should now be on the VGA output.
```

`video_selftest()` writes both pages completely before reading either back, so a page address line
(MA16, i.e. U1 pin 21 to U9 pin 2) that is stuck or shorted shows up as a failure rather than as a
picture that is subtly wrong.

| Symptom | Likely cause |
|---|---|
| Self test fails at byte 0 of page 1 only | MA16 — U1 pin 21, U9 pin 2 |
| Self test fails on a regular pattern of bytes | an MA line: check U5–U8 outputs against U9 pins |
| Bus error on the first VRAM write | `/DTACK` — U1 pin 18 to J1 pin 57 |
| Self test passes, screen stays black | `VIDEO_ON` (U1 pin 20 → U2 pin 11), or `/LOAD` (U2 pin 18 → U11 pin 15) |
| A picture, but every eighth pixel column wrong | U11 data pins: A = MD0 … H = MD7 |
| The picture is mirrored inside each byte | same — A and H swapped |
| Picture shifted sideways by one byte | U3's HBLANK decode; it should stop the load at byte 79 |

## 5. Things worth a scope

- **The control register write.** U1 pin 1 is `/LDS`, so the register loads on the *rising* edge of
  the strobe and depends on the 68010 still holding data and on `/EXPSEL` still being low at that
  moment. It is the one place on this card where the margin is set by the mainboard rather than by
  this design ([DESIGN §6](DESIGN.md#6-bus-cycle-u1)). If page flipping is unreliable, look here
  first.
- **The video byte fetch.** BCLK rising (U2 pin 17) to valid data on U9's DQ pins should be under
  about 90 ns of the 318 ns available.
- **Snow.** Writing to VRAM while the picture is on will flicker eight pixels on the current line.
  That is expected; draw on the hidden page and `video_flip()`.

## 6. Still to be verified on real hardware

Everything below has only been checked in simulation or on paper:

- programming real ATF22V10C parts and their actual propagation delays;
- 68010 data hold after `/LDS` rises, for the control register;
- the 0.62 V video level on a real monitor, and monitor tolerance of the timing;
- a build with the rosco_m68k toolchain;
- the board itself — no PCB has been ordered.
