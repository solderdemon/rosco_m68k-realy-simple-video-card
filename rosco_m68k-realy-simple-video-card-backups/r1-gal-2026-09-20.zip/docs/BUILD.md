# Regenerating this card

Nothing in this project is edited by hand except `tools/`, `pld/`, `software/` and the
`.kicad_pro` file. The schematic, the symbol library, the footprints, the PCB, `design.json`,
`BOM.csv` and the manufacturing outputs are all generated, and the next run of the generator
overwrites them. Open KiCad to *look* at the result, not to change it.

## Tools

| What | Where |
|---|---|
| KiCad 10 | `C:/Program Files/KiCad/10.0/bin/python.exe`, `kicad-cli.exe` |
| GALasm 2.1 | on `PATH`, or call the binary directly |
| Java | Temurin **25 or newer** — Freerouting 2.4.1 is built for class file 69 and will not start on 21 |
| Freerouting | `../tools/freerouting-2.4.1.jar`, found automatically |
| clang (or any C compiler) | only for the host driver test |

Anything that imports `pcbnew` has to run under KiCad's own Python, not the system one.

## The pipeline

Each step is a gate: move on only when the current one is clean.

```sh
K="/c/Program Files/KiCad/10.0/bin"
N=rosco_m68k-realy-simple-video-card

# 1. GAL logic -> JEDEC. Needs galasm on PATH.
./pld/build.sh

# 2. The 8x8 console font -> software/font8x8.c (only after editing the pictures in make_font.py)
python tools/make_font.py

# 3. Schematic, symbols, footprints, placement, BOM, design.json, routing.dsn
"$K/python.exe" tools/build_card.py

# 4. Logic simulation of the whole netlist against the real GAL fuses (~15 min)
python tools/sim_card.py

# 5. The driver against a model of the card
make -C software host-test

# 6. Freerouting swarm, GND pours, thermal repair, stub sweep
"$K/python.exe" tools/route_card.py

# 7. The gates
"$K/kicad-cli.exe" sch erc -o erc.rpt $N.kicad_sch
"$K/kicad-cli.exe" pcb drc --schematic-parity --severity-error --severity-warning \
    -o drc.rpt $N.kicad_pcb
```

Step 3 always writes a board with **no tracks**; `route_card.py` counts on that and refuses with
`board already routed` otherwise. Rerouting therefore means regenerating first.

## Manufacturing outputs

```sh
"$K/kicad-cli.exe" pcb export gerbers -o manufacturing/ $N.kicad_pcb
"$K/kicad-cli.exe" pcb export drill   -o manufacturing/ $N.kicad_pcb
"$K/kicad-cli.exe" pcb export pos --format csv --units mm -o manufacturing/$N-pos.csv $N.kicad_pcb
"$K/kicad-cli.exe" sch export pdf -o manufacturing/$N-schematic.pdf $N.kicad_sch
```

## Where things are decided

| Question | File |
|---|---|
| What the logic does, and every GAL pin number | `pld/*.pld` |
| Which chips exist, how they are wired, where they sit | `tools/build_card.py` |
| DRC rules, net classes, severities | `<project>.kicad_pro` (never written by a script) |
| Corner radius and routing options | `tools/route_card.py` |
| Font glyphs | `tools/make_font.py` |

`build_card.py` reads the GAL pin names straight out of `pld/*.pld`, so moving a signal to another
pin is a one-line change there and the schematic follows. It also re-imports KiCad's own netlist at
the end and copies the nets onto the pads, which catches any disagreement between what the
generator thought it built and what KiCad read.

## Routing notes

`tools/route_card.py` is a six-line wrapper around `../../tools/route_lib.py`, shared with every
other card in this workspace. `ROUTE_MODE=fast` (the default) stops at the first candidate that is
DRC clean; use `ROUTE_MODE=best` for a final revision. The measured behaviour of Freerouting —
why it runs as a swarm of processes, which command-line levers matter and which do nothing — is
written up once, in the workspace [AGENTS.md](../../AGENTS.md) §6.
