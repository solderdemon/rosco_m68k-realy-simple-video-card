"""rosco_m68k Really Simple Video r1: schematic + PCB placement generator. Run with KiCad 10 python.

VGA framebuffer card: 640 x 480, 1 bit per pixel, 2 pages, 11 DIP ICs.

The logic lives in four ATF22V10C (GALasm sources and JEDEC files in pld/, pin lists read from
there):
  U1 bus interface: card select, SRAM /WE /OE, 74HCT245 enable, /DTACK, control register,
     status, and SRAM A16 (CPU A17 during a card cycle, the displayed page otherwise);
  U2 pixel phase PH0-PH2, byte clock BCLK = /PH2, 74AC166 load, blanking, VSYNC;
  U3 byte counter B = 0..99 with HSYNC and HBLANK, clocked by BCLK;
  U4 line counter L = 0..524, clocked by the end of HSYNC.
Memory: one AS6C1008 (128K) holds 2 pages of 480 x 128 bytes: address = page:L[8:0]:B[6:0].
A 128 byte row stride makes that pure concatenation -- no adder, and four 74HCT157 are enough
to give the SRAM either the video address or the CPU address A16..A1. A 74AC166 turns the byte
into eight pixels; three resistors take it to R, G and B.
VRAM at odd addresses $A00001 + 2n, control and status at $B00001.
"""
from pathlib import Path
import subprocess, sys, xml.etree.ElementTree as ET
import videolib as g
import gal
import pcbnew as pcb

ROOT = Path(__file__).resolve().parents[1]
CLI = 'C:/Program Files/KiCad/10.0/bin/kicad-cli.exe'
g.LIB = Path('C:/Program Files/KiCad/10.0/share/kicad')
NAME = 'rosco_m68k-realy-simple-video-card'
BASE = 0xA00000          # decoded in pld/u1_bus.pld; only used for notes and silkscreen here
REG = 0xB00001
REV = 'r1'
W, H = 100.0, 96.0

d = g.Design(NAME, 'rosco_m68k Really Simple Video / VGA 640x480 mono, 4x ATF22V10C + SRAM', REV,
             '2026-09-20', paper='A2', libname='RoscoReallySimpleVideo', ns='rosco-really-simple-video-r1/')
DIP = lambda n, w=7.62: f'Package_DIP:DIP-{n}_W{w:.2f}mm_Socket_LongPads'
FP_C = 'Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm'
FP_CP = 'Capacitor_THT:CP_Radial_D6.3mm_P2.50mm'
FP_R = 'Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal'
FP_BUS = 'RoscoReallySimpleVideo:PinSocket_2x32_P2.54mm_Horizontal_CardEdge'
FP_VGA = 'RoscoReallySimpleVideo:DSUB-15-HD_Socket_Horizontal_P2.29x1.90mm_EdgePinOffset3.03mm_Housed_MountingHolesOffset4.94mm'
FP_OSC = 'Oscillator:Oscillator_DIP-8'
LOCAL_FP = ROOT / 'RoscoReallySimpleVideo.pretty'


def named(key, m):
    """Map pins by name; every name in the symbol must be listed (None = no-connect)."""
    pins = {}
    for p in d._pins(key):
        pins[g.one(p, 'name')[1]] = (g.one(p, 'number')[1], p[1])
    assert set(m) == set(pins), (key, 'unknown', set(m) - set(pins), 'missing', set(pins) - set(m))
    for name, (num, typ) in pins.items():
        assert m[name] or typ not in ('input', 'power_in'), f'{key}: input {name} left open'
    return {num: m[name] for name, (num, typ) in pins.items()}


# ---- J1: rosco_m68k r2 expansion bus (JP3 pinout) ---------------------------
bus = {1 + 2 * i: f'A{i + 1}' for i in range(23)}
bus.update({2: '+5V', 4: 'CLK', 6: 'GND', 8: '~{VPA}', 10: 'E', 12: '~{VMA}', 14: '~{IRQ3}', 16: '~{IOSEL}', 18: '~{EXPSEL}',
            20: 'FC0', 22: 'FC1', 24: 'FC2', 26: '~{IRQ5}', 28: '~{IRQ2}', 30: '~{IRQ6}', 32: '~{LDS}', 34: '~{UDS}', 36: '~{RESET}',
            47: '~{AS}', 49: '~{BERR}', 51: '~{BG}', 53: '~{BGACK}', 55: '~{BR}', 57: '~{DTACK}', 59: 'RWB', 61: 'D0', 63: 'D1'})
bus.update({38 + 2 * i: f'D{15 - i}' for i in range(14)})
used = ({'+5V', 'GND', '~{EXPSEL}', '~{LDS}', '~{RESET}', '~{DTACK}', 'RWB'}
        | {f'A{i}' for i in list(range(1, 18)) + [20, 21, 22, 23]} | {f'D{i}' for i in range(8)})
k = d.custom('BUS_2x32', [(i, bus[i], 'passive') for i in range(1, 65, 2)], [(i, bus[i], 'passive') for i in range(2, 65, 2)], FP_BUS, ref='J')
d.add('J1', k, 'ROSCO_M68K BUS', {i: n if n in used else None for i, n in bus.items()}, (40, 110))

# ---- U1..U4: ATF22V10C. Pin names and directions come from the GALasm sources ----
NET = {'LDS': '~{LDS}', 'EXPSEL': '~{EXPSEL}', 'RESET': '~{RESET}', 'RW': 'RWB', 'DTACK': '~{DTACK}',
       'SEL': '~{SEL}', 'SRAMWE': '~{SRAM_WE}', 'SRAMOE': '~{SRAM_OE}', 'BUFOE': '~{BUF_OE}',
       'VIDEOON': 'VIDEO_ON', 'HSYNC': '~{HSYNC}', 'VSYNC': '~{VSYNC}', 'LOAD': '~{LOAD}'}
for u, (ref, src) in enumerate(gal.GALS.items()):
    text = (ROOT / 'pld' / f'{src}.pld').read_text(encoding='utf-8')
    names, outs = gal.pins(text), gal.signals(text)

    def pin(p, names=names, outs=outs):
        n = names[p]
        if n in ('GND', 'VCC'): return (p, n, 'power_in')
        if n == 'NC': return (p, f'NC{p}', 'no_connect' if p >= 14 else 'input')
        return (p, n, {'tri': 'tri_state', 'reg': 'output', 'comb': 'output'}.get(outs.get(n), 'input'))
    key = d.custom(f'ATF22V10C_{src.split("_", 1)[1].upper()}', [pin(p) for p in list(range(1, 12)) + [13]],
                   [pin(p) for p in range(14, 25)] + [pin(12)], DIP(24), width=30.48)
    nets = {}
    for p, n in names.items():
        if n == 'VCC': nets[p] = '+5V'
        elif n == 'GND': nets[p] = 'GND'
        elif n == 'NC': nets[p] = 'GND' if p < 14 else None        # unused inputs tied low
        else: nets[p] = NET.get(n, n)
    d.add(ref, key, 'ATF22V10C', nets, (110, 40 + 75 * u))

# ---- U5..U8: address muxes. S = /SEL: 0 = CPU A16..A1 (I0), 1 = video address (I1) ----
video = [f'B{i}' for i in range(7)] + [f'L{i}' for i in range(9)]
k = d.standard('74xx', '74LS157', DIP(16))
for u in range(4):
    m = {'S': '~{SEL}', 'E': 'GND', 'VCC': '+5V', 'GND': 'GND'}
    for j, ch in enumerate('abcd'):
        bit = 4 * u + j
        m[f'I0{ch}'], m[f'I1{ch}'], m[f'Z{ch}'] = f'A{bit + 1}', video[bit], f'MA{bit}'
    d.add(f'U{5 + u}', k, '74HCT157', named(k, m), (200, 25 + 42 * u))

# ---- U9: 128K SRAM, 2 pages of 480 x 128 bytes. A16 comes from U1 ----
k = d.standard('Memory_RAM', 'AS6C1008-xxP', DIP(32, 15.24))
m = {'GND': 'GND', 'VCC': '+5V', '~{CS1}/~{CE1}': 'GND', 'CS2/CE2': '+5V',
     '~{OE}': '~{SRAM_OE}', '~{WE}': '~{SRAM_WE}', 'NC': None}
m.update({f'A{i}': f'MA{i}' for i in range(17)})
m.update({f'DQ{i}': f'MD{i}' for i in range(8)})
d.add('U9', k, 'AS6C1008-55PCN', named(k, m), (270, 90))

# ---- U10: data transceiver. A = SRAM side, B = CPU side; DIR = R/W (1 = read: SRAM -> CPU) ----
k = d.standard('74xx', '74HC245', DIP(20))
m = {'A->B': 'RWB', 'CE': '~{BUF_OE}', 'VCC': '+5V', 'GND': 'GND'}
m.update({f'A{i}': f'MD{i}' for i in range(8)})
m.update({f'B{i}': f'D{i}' for i in range(8)})
d.add('U10', k, '74HCT245', named(k, m), (270, 200))

# ---- U11: pixel serialiser. Loads a byte on /LOAD and shifts the MSB (leftmost pixel) out
#      first; while blanking U2 holds /LOAD high and the grounded serial input shifts black in.
k = d.standard('74xx', '74LS166', DIP(16))
m = {'Ds': 'GND', 'CE': 'GND', 'Clk': 'CLK25', 'Clr': '+5V', 'PE': '~{LOAD}', 'Qh': 'PIXEL',
     'VCC': '+5V', 'GND': 'GND'}
m.update({ch: f'MD{i}' for i, ch in enumerate('ABCDEFGH')})
d.add('U11', k, '74AC166', named(k, m), (340, 90))

# ---- X1: 25.175 MHz can into U2 pin 1 and the 74AC166 shift clock ----
k = d.standard('Oscillator', 'CXO_DIP8', FP_OSC)
d.add('X1', k, '25.175MHz', {1: '+5V', 4: 'GND', 5: 'CLK25', 8: '+5V'}, (340, 200))

# ---- one pixel bit into three 75 ohm inputs: 470 ohm each gives about 0.62 V white ----
R = d.standard('Device', 'R', FP_R)
for i, (ref, out) in enumerate([('R1', 'VGA_R'), ('R2', 'VGA_G'), ('R3', 'VGA_B')]):
    d.add(ref, R, '470', {1: 'PIXEL', 2: out}, (440, 40 + 30 * i))
d.add('R4', R, '47', {1: '~{HSYNC}', 2: 'VGA_HS'}, (440, 170))
d.add('R5', R, '47', {1: '~{VSYNC}', 2: 'VGA_VS'}, (470, 170))
k = d.standard('Connector', 'DE15_Socket_HighDensity_MountingHoles', FP_VGA)
vga = {1: 'VGA_R', 2: 'VGA_G', 3: 'VGA_B', 4: None, 5: 'GND', 6: 'GND', 7: 'GND', 8: 'GND', 9: None, 10: 'GND',
       11: None, 12: None, 13: 'VGA_HS', 14: 'VGA_VS', 15: None, 'SH': 'GND'}
d.add('J2', k, 'VGA', vga, (530, 100))

# ---- power ---------------------------------------------------------------------
C = d.standard('Device', 'C', FP_C)
CP = d.standard('Device', 'C_Polarized', FP_CP)
FLG = d.standard('power', 'PWR_FLAG', '')
for i in range(1, 13):                                                     # C1..C11 bypass U1..U11, C12 X1
    d.add(f'C{i}', C, '100nF', {1: '+5V', 2: 'GND'}, (380 + 15.24 * ((i - 1) % 12), 290))
d.add('C13', CP, '47uF 10V', {1: '+5V', 2: 'GND'}, (380, 350))
d.add('#FLG01', FLG, 'PWR_FLAG', {1: '+5V'}, (455, 345))
d.add('#FLG02', FLG, 'PWR_FLAG', {1: 'GND'}, (475, 345))

d.note(f'VRAM ${BASE:06X}-${BASE + 0xFFFFF:06X}: byte access (LDS) only, byte n of the SRAM at ${BASE + 1:06X} + 2n. '
       f'n = page << 16 | y << 7 | x >> 3 (x < 640, y < 480); bit 7 of the byte is the leftmost pixel.', 20, 385, 2)
d.note(f'${REG:06X} write: b0 displayed page, b1 video on (reset: 0, screen black). Read: b0 VBLANK, b1 HBLANK. '
       f'The register repeats over $B00001-$BFFFFF.', 20, 391, 2)
d.note('U1-U4 ATF22V10C: pld/u1_bus, u2_timing, u3_column, u4_line (GALasm). VGA 640x480 @ 60 Hz from 25.175 MHz: '
       '100 bytes per line, HSYNC byte times 83-94, VSYNC lines 490-491, both active low.', 20, 397, 2)

for p in d.parts:                                   # GAL outputs nobody reads stay unconnected
    if p['ref'] in gal.GALS:
        for pin_, net in p['nets'].items():
            if net and len(d.netlist()[net]) == 1:
                p['nets'][pin_] = None

d.write(ROOT, [('RoscoReallySimpleVideo', '${KIPRJMOD}/RoscoReallySimpleVideo.pretty')])
subprocess.run([sys.executable, str(Path(__file__).with_name('make_bus_footprint.py'))], check=True)

# ---- PCB -----------------------------------------------------------------------
b = pcb.BOARD()
b.SetCopperLayerCount(2)
v = lambda x, y: pcb.VECTOR2I(pcb.FromMM(x), pcb.FromMM(y))
nets = {}
for i, n in enumerate(sorted(d.netlist()), 1):
    ni = pcb.NETINFO_ITEM(b, '/' + n, i)
    b.Add(ni)
    nets[n] = ni
fps = {}
for p in d.parts:
    if p['ref'].startswith('#'):
        continue
    lib, name = p['fp'].split(':')
    f = pcb.FootprintLoad(str(LOCAL_FP if lib == 'RoscoReallySimpleVideo' else g.LIB / 'footprints' / (lib + '.pretty')), name)
    assert f, p['fp']
    f.SetFPID(pcb.LIB_ID(lib, name))
    f.SetReference(p['ref'])
    f.SetValue(p['value'])
    f.SetPath(pcb.KIID_PATH('/' + d.uid('root') + '/' + p['uuid']))
    for pad in f.Pads():
        net = p['nets'].get(pad.GetNumber())
        if net:
            pad.SetNet(nets[net])
    f.Value().SetVisible(False)
    f.Reference().SetTextSize(v(1, 1))
    f.Reference().SetTextThickness(pcb.FromMM(.15))
    b.Add(f)
    fps[p['ref']] = f


def place(ref, x, y, rot=0, pin1=False):
    """pin1=True: (x, y) is pad 1; otherwise the footprint body is centred on (x, y)."""
    f = fps[ref]
    f.SetOrientationDegrees(rot)
    f.SetPosition(v(0, 0))
    if pin1:
        f.SetPosition(v(x, y))
        return f
    c = f.GetBoundingBox(False).GetCenter()
    f.SetPosition(pcb.VECTOR2I(pcb.FromMM(x) - c.x, pcb.FromMM(y) - c.y))
    return f


def ref_at(ref, x, y, angle=0):
    t = fps[ref].Reference()
    t.SetPosition(v(x, y))
    t.SetTextAngle(pcb.EDA_ANGLE(angle, pcb.DEGREES_T))


def dip_width(ref):
    f = place(ref, 0, 0, 270)
    return pcb.ToMM(f.GetBoundingBox(False).GetWidth())


def dip(ref, left, y):
    """DIP lying horizontally, pin 1 towards the bus (right), left edge at `left`; cap to its right."""
    f = place(ref, left + 13, y, 270)
    f.Move(pcb.VECTOR2I(pcb.FromMM(left) - f.GetBoundingBox(False).GetLeft(), 0))
    right = pcb.ToMM(f.GetBoundingBox(False).GetRight())
    ref_at(ref, left - 1.3, y, 90)
    cref = f'C{ref[1:]}'
    place(cref, right + 2.2, y, 90)
    ref_at(cref, right + 2.2 + 2.8, y, 90)
    return right + 4.0


ROW = [8.6 + 14.6 * i for i in range(6)]
BX = W - 6.0
place('J1', BX, 87.37, 180, pin1=True)
ref_at('J1', BX + 1.27, 91.2)

# Column A against J1: transceiver and bus GAL at the data pins, the four muxes at A1..A16.
EDGE = W - 10.5
for row, ref in enumerate(['U10', 'U1', 'U5', 'U6', 'U7', 'U8']):
    dip(ref, EDGE - 5.0 - dip_width(ref), ROW[row])

# Column B along the left edge: the three timing GALs, then the SRAM and the serialiser.
COL_B = 3.0
for row, ref in enumerate(['U3', 'U4', 'U2']):
    dip(ref, COL_B, ROW[row])
dip('U9', COL_B, 62.0)
dip('U11', COL_B, 80.0)

# Oscillator and the bulk capacitor go in the open channel between the two columns.
place('X1', 52.0, 52.0, 0)
ref_at('X1', 52.0, 44.6)
place('C12', 58.0, 62.0, 90)
ref_at('C12', 60.8, 62.0, 90)
place('C13', 58.0, 33.0, 0)
ref_at('C13', 58.0, 37.8)

# VGA socket on the bottom edge with its five series resistors straight above its pins.
RES_X0, RES_Y = 33.0, 79.0
for i, ref in enumerate(['R4', 'R5', 'R1', 'R2', 'R3']):
    x = RES_X0 + 3.4 * i
    place(ref, x, RES_Y, 90)
    ref_at(ref, x, RES_Y - 6.3, 90)
J2_PIN1_X = 47.0
place('J2', J2_PIN1_X, H - 6.83, 0, pin1=True)
ref_at('J2', 22.0, 94.5)


def seg(a, z, layer=pcb.F_SilkS, line=.15):
    e = pcb.PCB_SHAPE(b)
    e.SetShape(pcb.SHAPE_T_SEGMENT)
    e.SetStart(v(*a))
    e.SetEnd(v(*z))
    e.SetLayer(layer)
    e.SetWidth(pcb.FromMM(line))
    b.Add(e)


def arc(start, mid, end):
    e = pcb.PCB_SHAPE(b)
    e.SetShape(pcb.SHAPE_T_ARC)
    e.SetArcGeometry(v(*start), v(*mid), v(*end))
    e.SetLayer(pcb.Edge_Cuts)
    e.SetWidth(pcb.FromMM(.05))
    b.Add(e)


def text(s, x, y, size=1.0, layer=pcb.F_SilkS, left=True, angle=0, bold=False):
    t = pcb.PCB_TEXT(b)
    t.SetText(s)
    t.SetPosition(v(x, y))
    t.SetTextSize(v(size, size))
    t.SetTextThickness(pcb.FromMM(size * (.2 if bold else .15)))
    t.SetLayer(layer)
    if left:
        t.SetHorizJustify(pcb.GR_TEXT_H_ALIGN_LEFT)
    if angle:
        t.SetTextAngle(pcb.EDA_ANGLE(angle, pcb.DEGREES_T))
    if layer == pcb.B_SilkS:
        t.SetMirrored(True)
    b.Add(t)


r = 3.0
k45 = r * (1 - 0.70710678)
seg((r, 0), (W - r, 0), pcb.Edge_Cuts, .05)
seg((W, r), (W, H - r), pcb.Edge_Cuts, .05)
seg((W - r, H), (r, H), pcb.Edge_Cuts, .05)
seg((0, H - r), (0, r), pcb.Edge_Cuts, .05)
arc((W - r, 0), (W - k45, k45), (W, r))
arc((W, H - r), (W - k45, H - k45), (W - r, H))
arc((r, H), (k45, H - k45), (0, H - r))
arc((0, r), (k45, k45), (r, 0))

# Silkscreen text goes in the strip below U8 and J2, clear of every pad; front and back overlap
# each other harmlessly because they are different layers. Everything is >= 0.8 mm tall.
text('rosco_m68k Really Simple Video', 62.0, 90.5, .85, bold=True)
text(f'{REV}  VGA 640x480 mono', 62.0, 93.5, .8)
text('BUS', BX + 1.27, 5, 1.0, left=False)
# Programmer's summary on the back of the same strip, in two blocks.
for i, line in enumerate([f'REALLY SIMPLE VIDEO {REV}', f'VRAM ${BASE + 1:06X} + 2n', 'n = page<<16|y<<7|x>>3',
                          'bit 7 = leftmost pixel', f'${REG:06X} W:b0 page b1 on']):
    text(line, 74.0, 87.8 + i * 1.5, .8, pcb.B_SilkS, left=False)
for i, line in enumerate(['R: b0 VBLANK b1 HBLANK', '2 pages, 80x60 chars',
                          'U1 bus   U2 timing', 'U3 column   U4 line']):
    text(line, 16.0, 87.8 + i * 1.5, .8, pcb.B_SilkS, left=False)

# No-connect pins get 'unconnected-(...)' nets in the schematic; copy nets and pin metadata onto the pads.
netlist = ROOT / 'netlist.xml'
subprocess.run([CLI, 'sch', 'export', 'netlist', '--format', 'kicadxml', '-o', str(netlist), str(ROOT / f'{NAME}.kicad_sch')], check=True, capture_output=True)
for n in ET.parse(netlist).findall('./nets/net'):
    for node in n.findall('node'):
        f = fps.get(node.get('ref'))
        pad = next((pd for pd in f.Pads() if pd.GetNumber() == node.get('pin')), None) if f else None
        if pad is None:
            continue
        ni = b.FindNet(n.get('name'))
        if ni is None:
            ni = pcb.NETINFO_ITEM(b, n.get('name'))
            b.Add(ni)
        pad.SetNet(ni)
        if node.get('pinfunction'):
            pad.SetPinFunction(node.get('pinfunction'))
        if node.get('pintype'):
            pad.SetPinType(node.get('pintype'))
netlist.unlink()

pcb.SaveBoard(str(ROOT / (NAME + '.kicad_pcb')), b)
pcb.ExportSpecctraDSN(b, str(ROOT / 'routing.dsn'))
print('Generated', len(d.parts), 'symbols;', len(nets), 'nets;', f'{W:g} x {H:g} mm')
