"""Zero-delay logic simulation of the generated netlist (design.json + symbol pin names).

Every IC is modelled by its function and wired exactly as build_card.py wired it, so wrong pins,
swapped polarities and decode mistakes show up here before they reach copper. The four ATF22V10C
run the JEDEC fuse maps GALasm produced from pld/*.pld (tools/gal.py), on the pins declared there.
Checks:
  * GAL counters: full sequence and recovery from every power-up state;
  * raster: 100 bytes x 800 clocks x 525 lines, HSYNC/VSYNC position and width, blanking;
  * CPU cycles through J1: VRAM write/read on both pages, register write/read, /DTACK,
    no DTACK outside the window, no data-bus contention, SRAM /WE only for VRAM writes;
  * picture: all 307200 pixels of a frame compared against the SRAM, bit by bit, plus a second
    pass after a page flip.
It proves logic, not timing. Run with any Python 3 (KiCad's is fine): writes sim-verification.txt.
"""
from pathlib import Path
import json, sys
from collections import defaultdict, deque

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
import videolib as g
import gal

LIBNAME = 'RoscoReallySimpleVideo'
parts = json.loads((ROOT / 'design.json').read_text())
local = g.parse((ROOT / f'{LIBNAME}.kicad_sym').read_text(encoding='utf-8'))


def pin_names(key):
    lib, name = key.split(':')
    sym = next(s for s in g.sub(local, 'symbol') if s[1] == name) if lib == LIBNAME else g.library_symbol(lib, name)
    out = {}
    for u in g.sub(sym, 'symbol'):
        for p in g.sub(u, 'pin'):
            out[str(g.one(p, 'number')[1])] = str(g.one(p, 'name')[1])
    return out


# ---- nets ----------------------------------------------------------------------------------
val = defaultdict(int)           # resolved net levels (0/1); undriven nets read 1 (pull-up/float high)
drivers = defaultdict(dict)      # net -> {driver id: 0/1/None}
readers = defaultdict(list)
contention = []
val['+5V'] = 1
val['GND'] = 0


def resolve(net):
    act = [x for x in drivers[net].values() if x is not None]
    if len(set(act)) > 1:
        contention.append((net, dict(drivers[net])))
    if net == '~{DTACK}':                      # open drain with the mainboard pull-up
        return 0 if 0 in act else 1
    return act[0] if act else 1


class Part:
    def __init__(self, p):
        self.ref, self.value = p['ref'], p['value']
        names = pin_names(p['key'])
        self.n = {names[num]: net for num, net in p['nets'].items() if net}
        for net in self.n.values():
            readers[net].append(self)

    def get(self, name, snap=None):
        net = self.n.get(name)
        if net is None:
            raise KeyError(f'{self.ref}.{name} not connected')
        return (snap if snap is not None else val)[net]

    def drive(self, name, v, changed):
        net = self.n.get(name)
        if net is None or net in ('+5V', 'GND'):
            return
        if drivers[net].get(self.ref, 'x') == v:
            return
        drivers[net][self.ref] = v
        nv = resolve(net)
        if nv != val[net]:
            val[net] = nv
            changed.append(net)


class Xcvr245(Part):
    def eval(self, ch, snap):
        on, a2b = not self.get('CE'), self.get('A->B')
        for i in range(8):
            self.drive(f'B{i}', self.get(f'A{i}') if on and a2b else None, ch)
            self.drive(f'A{i}', self.get(f'B{i}') if on and not a2b else None, ch)


class Sram(Part):
    BITS = 17

    def __init__(self, p):
        super().__init__(p)
        self.mem = bytearray(1 << self.BITS)
        self.writes = 0

    def eval(self, ch, snap):
        a = sum(self.get(f'A{i}') << i for i in range(self.BITS))
        ce = self.get('~{CS1}/~{CE1}') or not self.get('CS2/CE2')
        oe, we = self.get('~{OE}'), self.get('~{WE}')
        if not ce and not we:
            self.mem[a] = sum(self.get(f'DQ{i}') << i for i in range(8))
            self.writes += 1
        out = not ce and not oe and we
        for i in range(8):
            self.drive(f'DQ{i}', self.mem[a] >> i & 1 if out else None, ch)


class Mux157(Part):
    def eval(self, ch, snap):
        s = self.get('S')
        for c in 'abcd':
            if f'Z{c}' in self.n:
                self.drive(f'Z{c}', 0 if self.get('E') else self.get(f'I{s}{c}'), ch)


class Shift166(Part):
    """74AC166: PE low loads A..H on the rising edge, otherwise shifts Ds into QA and QG into QH."""
    def __init__(self, p):
        super().__init__(p)
        self.last = None
        self.q = [0] * 8

    def eval(self, ch, snap):
        c = self.get('Clk')
        if self.last is not None and c and not self.last and not self.get('CE', snap):
            if not self.get('PE', snap):
                self.q = [self.get(x, snap) for x in 'ABCDEFGH']
            else:
                self.q = [self.get('Ds', snap)] + self.q[:7]
        self.last = c
        if not self.get('Clr'):
            self.q = [0] * 8
        self.drive('Qh', self.q[7], ch)


class Gal(Part):
    """ATF22V10C running its JEDEC file; registers clock on the rising edge of pin 1."""
    def __init__(self, p):
        self.ref, self.value = p['ref'], p['value']
        src = ROOT / 'pld' / gal.GALS[p['ref']]
        self.dev = gal.Gal22V10(gal.jedec(src.with_suffix('.jed').read_text(encoding='latin-1')))
        # An output pin that nothing on the board reads still feeds its own OLMC back -- the
        # feedback mux takes the pin, which the output buffer drives. Give it a net of its own,
        # named after the signal, so the model sees the same thing the chip does.
        names = gal.pins(src.with_suffix('.pld').read_text())
        self.n = {}
        for pin, net in p['nets'].items():
            if net:
                self.n[pin] = net
            elif int(pin) >= 14 and names[int(pin)] != 'NC':
                self.n[pin] = names[int(pin)]
        for net in set(self.n.values()):
            readers[net].append(self)
        self.last = None

    def eval(self, ch, snap):
        c = val[self.n['1']]
        if self.last is not None and c and not self.last:
            self.dev.clock({int(pin): snap[net] for pin, net in self.n.items()})
        self.last = c
        for pin, v in self.dev.outputs({int(pin): val[net] for pin, net in self.n.items()}).items():
            if str(pin) in self.n:
                self.drive(str(pin), v, ch)


MODELS = {'74HCT245': Xcvr245, '74HCT157': Mux157, 'AS6C1008-55PCN': Sram, '74AC166': Shift166, 'ATF22V10C': Gal}
P = {}
for p in parts:
    cls = MODELS.get(p['value'])
    if cls:
        P[p['ref']] = cls(p)
assert len([r for r in P if r.startswith('U')]) == 11, sorted(P)
sram = P['U9']
CPU = 'J1'


def settle(snap, start=None):
    queue = deque(P.values() if start is None else start)
    queued = set(queue)
    guard = 0
    while queue:
        guard += 1
        assert guard < 200000, 'combinational loop'
        part = queue.popleft()
        queued.discard(part)
        ch = []
        part.eval(ch, snap)
        for net in ch:
            for r in readers[net]:
                if r not in queued:
                    queue.append(r)
                    queued.add(r)


def cpu(**sig):
    """Drive J1 nets (None releases a bus line) and settle."""
    snap = dict(val)
    start = set()
    for net, v in sig.items():
        net = {'EXPSEL': '~{EXPSEL}', 'LDS': '~{LDS}', 'RESET': '~{RESET}'}.get(net, net)
        drivers[net][CPU] = v
        val[net] = resolve(net)
        start.update(readers[net])
    settle(snap, start)


def set_addr(a):
    cpu(**{f'A{i}': a >> i & 1 for i in range(1, 24)})


TICKS = 0


def tick():
    global TICKS
    TICKS += 1
    snap = dict(val)
    drivers['CLK25']['X1'] = 1 - val['CLK25']
    val['CLK25'] = resolve('CLK25')
    settle(snap, readers['CLK25'])


def expsel(a):
    """rosco r2 PLD: /EXPSEL = /AS * (A23*/A21 + /A23*A22 + /A23*A20 + /A22*A21)."""
    b = lambda n: a >> n & 1
    return 0 if (b(23) and not b(21)) or (not b(23) and b(22)) or (not b(23) and b(20)) or (not b(22) and b(21)) else 1


LAST = {}


def cycle(a, data=None):
    """One 68010 byte cycle: address + R/W, then AS (-> /EXPSEL), data, /LDS; returns (dtack, byte read)."""
    rw = 1 if data is None else 0
    assert a & 1, 'byte cycles on odd addresses use /LDS'
    set_addr(a)
    cpu(RWB=rw)
    cpu(EXPSEL=expsel(a))
    if data is not None:
        cpu(**{f'D{i}': data >> i & 1 for i in range(8)})
    tick(); tick()                                   # video keeps running during the cycle
    cpu(LDS=0)
    tick(); tick()
    dtack = val['~{DTACK}'] == 0
    got = sum(val[f'D{i}'] << i for i in range(8))
    LAST.update(vbl=val['VBLANK'], hbl=val['HBLANK'],
                drv={r for i in range(8) for r, x in drivers[f'D{i}'].items() if x is not None and r != CPU})
    cpu(LDS=1)
    cpu(EXPSEL=1)
    tick()
    cpu(RWB=1, **{f'D{i}': None for i in range(8)})
    return dtack, (got if rw else None)


log = []


def check(cond, msg):
    log.append(('PASS ' if cond else 'FAIL ') + msg)
    if not cond:
        print('FAIL', msg)


# ---- GAL counters on their own: full sequence, and every power-up state reaches the cycle ----
def counter(ref, bits, n):
    """Run one GAL on its own, feeding its output pins back as the combinational feedback does."""
    src = ROOT / 'pld' / gal.GALS[ref]
    dev = gal.Gal22V10(gal.jedec(src.with_suffix('.jed').read_text(encoding='latin-1')))
    names = gal.pins(src.with_suffix('.pld').read_text())
    pinof = {name: pin for pin, name in names.items()}
    outs = [p for p in range(14, 24)]
    width = len([k for k in pinof if k.startswith(bits) and k[len(bits):].isdigit()])
    # One pass is enough unless a combinational output feeds the next state (U3's LAST).
    passes = 2 if 'comb' in gal.signals(src.with_suffix('.pld').read_text()).values() else 1

    def levels():
        lv = {p: 0 for p in outs}
        for _ in range(passes):
            o = dev.outputs(lv)
            lv = {p: (0 if o[p] is None else o[p]) for p in outs}
        return lv

    def value(lv):
        return sum(lv[pinof[f'{bits}{i}']] << i for i in range(width))

    seq = []
    for _ in range(n + 1):
        lv = levels()
        seq.append(value(lv))
        dev.clock(lv)
    worst = 0
    for start in range(1 << width):
        for i in range(width):
            dev.q[pinof[f'{bits}{i}']] = start >> i & 1
        steps = 2 * n
        for steps in range(2 * n):
            lv = levels()
            if value(lv) == 0:
                break
            dev.clock(lv)
        worst = max(worst, steps) if value(lv) == 0 else 10 ** 9
    return seq == list(range(n)) + [0], worst


ok, worst = counter('U3', 'B', 100)
check(ok and worst < 100, f'U3 counts B 0..99 and reaches 0 from all 128 power-up states (worst {worst} clocks)')
ok, worst = counter('U4', 'L', 525)
check(ok and worst < 525, f'U4 counts L 0..524 and reaches 0 from all 1024 power-up states (worst {worst} clocks)')

# ---- power-on ---------------------------------------------------------------------------------
drivers['CLK25']['X1'] = 0
val['CLK25'] = 0
cpu(EXPSEL=1, LDS=1, RWB=1, RESET=0, **{f'A{i}': 0 for i in range(1, 24)})
settle(dict(val))
tick(); tick()
cpu(RESET=1)
check(val['VIDEO_ON'] == 0, 'system reset clears the control register (video off, page 0)')
for _ in range(16):
    tick()
check(val['BLANK'] == 1 and val['PIXEL'] == 0, 'video off: BLANK held, no pixels leave the 74AC166')

# ---- CPU access -------------------------------------------------------------------------------
BASE = 0xA00000
REG = 0xB00001


def vaddr(page, x, y):
    return BASE + 1 + 2 * (page << 16 | y << 7 | x >> 3)


dt, _ = cycle(REG, 0x02)
check(dt, 'register write acknowledged')
check(val['VIDEO_ON'] == 1 and val['PAGE'] == 0, 'control register = video on, page 0')
w = sram.writes
dt, st = cycle(REG)
check(dt and st & 1 == LAST['vbl'] and st >> 1 & 1 == LAST['hbl'] and LAST['drv'] == {'U1'},
      f'status read acknowledged: D0 = VBLANK, D1 = HBLANK, driven only by U1 (read {st:#04x})')
dt, _ = cycle(0xBFFFFF, 0x02)
check(dt and val['VIDEO_ON'] == 1, 'the register repeats up to $BFFFFF')
check(sram.writes == w, 'register cycles never write the SRAM')

import random
random.seed(68010)
pattern = {}
for page in (0, 1):
    for y, x in [(0, 0), (479, 632)] + [(random.randrange(480), random.randrange(80) * 8) for _ in range(20)]:
        pattern[(page, x, y)] = random.randrange(256)
acks = sum(cycle(vaddr(p, x, y), c)[0] for (p, x, y), c in pattern.items())
check(acks == len(pattern), f'{len(pattern)} VRAM writes on both pages acknowledged')
check(all(sram.mem[p << 16 | y << 7 | x >> 3] == c for (p, x, y), c in pattern.items()),
      'each byte landed in SRAM cell page << 16 | y << 7 | x >> 3')
ok = True
for (page, x, y), c in pattern.items():
    dt, got = cycle(vaddr(page, x, y))
    ok &= dt and got == c
check(ok, 'every byte reads back through the 74HCT245')
for a in (0x900001, 0xC00001, 0xF40001, 0x000001):
    dt, _ = cycle(a)
    check(not dt, f'no /DTACK outside $A00000-$BFFFFF (${a:06X})')
w = sram.writes
cycle(0x900001, 0x55)
check(sram.writes == w, 'writes outside the window leave the SRAM alone')
bus = [c for c in contention if c[0].startswith(('D', 'MD'))]
check(not bus, f'no contention on D0-D7 / MD0-MD7 during CPU cycles ({len(bus)} events)')

# ---- fill both pages with a deterministic picture ---------------------------------------------
random.seed(1802)
rows = {}
for page in (0, 1):
    for y in range(480):
        seed = (page * 7919 + y * 31) & 0xFF
        for bx in range(80):
            sram.mem[page << 16 | y << 7 | bx] = (seed ^ (bx * 37 + y)) & 0xFF
    rows[page] = True

# ---- raster + picture -------------------------------------------------------------------------
B = lambda: sum(val[f'B{i}'] << i for i in range(7))
L = lambda: sum(val[f'L{i}'] << i for i in range(10))
PH = lambda: val['PH0'] | val['PH1'] << 1 | val['PH2'] << 2

cycle(REG, 0x02)                                     # video on, page 0
while not (L() == 0 and B() == 0 and PH() == 0 and val['CLK25'] == 1):
    tick()
check(L() == 0 and B() == 0, 'counters reach byte 0 of line 0')


def scan(page, lines, want_raster=False):
    """Walk `lines` raster lines from the current position, comparing every pixel with the SRAM."""
    bad, lit, hs_fall, hs_run, hs_widths, vs_lines, line_len, mark = [], [], [], 0, set(), set(), set(), None
    prev_hs = val['~{HSYNC}']
    for _ in range(lines * 800):
        tick()                                       # rising edge: new pixel, new B/PH
        b, ph, l, pix, hs = B(), PH(), L(), val['PIXEL'], val['~{HSYNC}']
        c = b * 8 + ph
        if 8 <= c <= 647 and l < 480:
            x = c - 8
            byte = sram.mem[page << 16 | l << 7 | (x >> 3)]
            if pix != (byte >> (7 - (x & 7)) & 1) and len(bad) < 5:
                bad.append((l, x, pix))
        elif pix and len(lit) < 5:
            lit.append((l, c, pix))
        if want_raster:
            if hs == 0:
                hs_run += 1
            if hs == 0 and prev_hs == 1:
                hs_fall.append((TICKS, c))
                if mark is not None:
                    line_len.add((TICKS - mark) // 2)
                mark = TICKS
            if hs == 1 and prev_hs == 0:
                hs_widths.add(hs_run)
                hs_run = 0
            if val['~{VSYNC}'] == 0:
                vs_lines.add(l)
            prev_hs = hs
        tick()                                       # falling edge
    return bad, lit, hs_fall, hs_widths, vs_lines, line_len


bad, lit, hs_fall, hs_widths, vs_lines, line_len = scan(0, 525, want_raster=True)
check(line_len == {800}, f'line = 800 clocks of 25.175 MHz = 31.469 kHz (measured {sorted(line_len)})')
check(len(hs_fall) == 525, f'525 lines per frame = 59.94 Hz (measured {len(hs_fall)})')
check({c for _, c in hs_fall} == {83 * 8}, f'HSYNC falls at clock 664 of the line, 16 clocks of front porch after pixel 639 (measured {sorted({c for _, c in hs_fall})})')
check(hs_widths == {96}, f'HSYNC is 96 clocks = 3.81 us (measured {sorted(hs_widths)})')
check(vs_lines == {490, 491} or vs_lines == {490, 491, 492},
      f'VSYNC covers lines 490-491 (measured {sorted(vs_lines)}; it is released one 25 MHz clock into 492)')
check(not bad, f'all 307200 pixels of page 0 match the SRAM, bit 7 leftmost {bad[:3]}')
check(not lit, f'the pixel line is 0 outside the 640 x 480 picture {lit[:3]}')

# ---- page flip ---------------------------------------------------------------------------------
while L() < 485:
    tick(); tick()
cycle(REG, 0x03)                                     # video on, page 1, inside vertical blanking
check(val['PAGE'] == 1, 'control register b0 selects page 1')
while not (L() == 0 and B() == 0 and PH() == 0 and val['CLK25'] == 1):
    tick()
bad, lit = scan(1, 4)[:2]
check(not bad and not lit, f'after the flip the first 4 lines come from page 1 {bad[:3]}{lit[:3]}')

bus = [c for c in contention if c[0].startswith(('D', 'MD'))]
check(not bus, f'no bus contention anywhere in the run ({len(bus)} events)')

out = '\n'.join(log) + f"\n\n{sum(x.startswith('PASS') for x in log)} passed, {sum(x.startswith('FAIL') for x in log)} failed\n"
(ROOT / 'sim-verification.txt').write_text(out)
print(out)
sys.exit(1 if 'FAIL' in out else 0)
